/*
www.sourceforge.net/projects/tinyxml
Original code (2.0 and earlier )copyright (c) 2000-2006 Lee Thomason (www.grinninglizard.com)

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any
damages arising from the use of this software.

Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and
redistribute it freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must
not claim that you wrote the original software. If you use this
software in a product, an acknowledgment in the product document_ation
would be appreciated but is not required.

2. Altered source versions must be plainly marked as such, and
must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source
distribution.
*/

//#include <cctype>
#include "tinyxml.h"

#ifdef TIXML_USE_STL
#include <sstream>
#include <iostream>
#endif

namespace tinyxml 
{

bool base::condenseWhiteSpace = true;

void base::PutString( const TIXML_STRING& str, TIXML_STRING* outString )
{
	int i=0;

	while( i<(int)str.length() )
	{
		unsigned char c = (unsigned char) str[i];

		if (    c == '&' 
		     && i < ( (int)str.length() - 2 )
			 && str[i+1] == '#'
			 && str[i+2] == 'x' )
		{
			// Hexadecimal character reference.
			// Pass through unchanged.
			// &#xA9;	-- copyright symbol, for example.
			//
			// The -1 is a bug fix from Rob Laveaux. It keeps
			// an overflow from happening if there is no ';'.
			// There are actually 2 ways to exit this loop -
			// while fails (error case) and break (semicolon found).
			// However, there is no mechanism (currently) for
			// this function to return an error.
			while ( i<(int)str.length()-1 )
			{
				outString->append( str.c_str() + i, 1 );
				++i;
				if ( str[i] == ';' )
					break;
			}
		}
		else if ( c == '&' )
		{
			outString->append( entity[0].str, entity[0].strLength );
			++i;
		}
		else if ( c == '<' )
		{
			outString->append( entity[1].str, entity[1].strLength );
			++i;
		}
		else if ( c == '>' )
		{
			outString->append( entity[2].str, entity[2].strLength );
			++i;
		}
		else if ( c == '\"' )
		{
			outString->append( entity[3].str, entity[3].strLength );
			++i;
		}
		else if ( c == '\'' )
		{
			outString->append( entity[4].str, entity[4].strLength );
			++i;
		}
		else if ( c < 32 )
		{
			// Easy pass at non-alpha/numeric/symbol
			// Below 32 is symbolic.
			char buf[ 32 ];
			
			#if defined(TIXML_SNPRINTF)		
				TIXML_SNPRINTF( buf, sizeof(buf), "&#x%02X;", (unsigned) ( c & 0xff ) );
			#else
				sprintf( buf, "&#x%02X;", (unsigned) ( c & 0xff ) );
			#endif		

			//*ME:	warning C4267: convert 'size_t' to 'int'
			//*ME:	Int-Cast to make compiler happy ...
			outString->append( buf, (int)strlen( buf ) );
			++i;
		}
		else
		{
			//char realc = (char) c;
			//outString->append( &realc, 1 );
			*outString += (char) c;	// somewhat more efficient function call.
			++i;
		}
	}
}


node::node( NodeType _type ) : base()
{
	parent = 0;
	type = _type;
	firstChild = 0;
	lastChild = 0;
	prev = 0;
	next = 0;
}


node::~node()
{
	node* node_ = firstChild;
	node* temp = 0;

	while ( node_ )
	{
		temp = node_;
		node_ = node_->next;
		delete temp;
	}	
}


void node::CopyTo( node* target ) const
{
	target->SetValue (value.c_str() );
	target->userData = userData; 
}


void node::Clear()
{
	node* node_ = firstChild;
	node* temp = 0;

	while ( node_ )
	{
		temp = node_;
		node_ = node_->next;
		delete temp;
	}	

	firstChild = 0;
	lastChild = 0;
}


node* node::LinkEndChild( node* node_ )
{
	assert( node_->parent == 0 || node_->parent == this );
	assert( node_->GetDocument() == 0 || node_->GetDocument() == this->GetDocument() );

	if ( node_->Type() == node::DOCUMENT )
	{
		delete node_;
		if ( GetDocument() ) GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0, TIXML_ENCODING_UNKNOWN );
		return 0;
	}

	node_->parent = this;

	node_->prev = lastChild;
	node_->next = 0;

	if ( lastChild )
		lastChild->next = node_;
	else
		firstChild = node_;			// it was an empty list.

	lastChild = node_;
	return node_;
}


node* node::InsertEndChild( const node& addThis )
{
	if ( addThis.Type() == node::DOCUMENT )
	{
		if ( GetDocument() ) GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0, TIXML_ENCODING_UNKNOWN );
		return 0;
	}
	node* node_ = addThis.Clone();
	if ( !node_ )
		return 0;

	return LinkEndChild( node_ );
}


node* node::InsertBeforeChild( node* beforeThis, const node& addThis )
{	
	if ( !beforeThis || beforeThis->parent != this ) {
		return 0;
	}
	if ( addThis.Type() == node::DOCUMENT )
	{
		if ( GetDocument() ) GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0, TIXML_ENCODING_UNKNOWN );
		return 0;
	}

	node* node_ = addThis.Clone();
	if ( !node_ )
		return 0;
	node_->parent = this;

	node_->next = beforeThis;
	node_->prev = beforeThis->prev;
	if ( beforeThis->prev )
	{
		beforeThis->prev->next = node_;
	}
	else
	{
		assert( firstChild == beforeThis );
		firstChild = node_;
	}
	beforeThis->prev = node_;
	return node_;
}


node* node::InsertAfterChild( node* afterThis, const node& addThis )
{
	if ( !afterThis || afterThis->parent != this ) {
		return 0;
	}
	if ( addThis.Type() == node::DOCUMENT )
	{
		if ( GetDocument() ) GetDocument()->SetError( TIXML_ERROR_DOCUMENT_TOP_ONLY, 0, 0, TIXML_ENCODING_UNKNOWN );
		return 0;
	}

	node* node_ = addThis.Clone();
	if ( !node_ )
		return 0;
	node_->parent = this;

	node_->prev = afterThis;
	node_->next = afterThis->next;
	if ( afterThis->next )
	{
		afterThis->next->prev = node_;
	}
	else
	{
		assert( lastChild == afterThis );
		lastChild = node_;
	}
	afterThis->next = node_;
	return node_;
}


node* node::ReplaceChild( node* replaceThis, const node& withThis )
{
	if ( replaceThis->parent != this )
		return 0;

	node* node_ = withThis.Clone();
	if ( !node_ )
		return 0;

	node_->next = replaceThis->next;
	node_->prev = replaceThis->prev;

	if ( replaceThis->next )
		replaceThis->next->prev = node_;
	else
		lastChild = node_;

	if ( replaceThis->prev )
		replaceThis->prev->next = node_;
	else
		firstChild = node_;

	delete replaceThis;
	node_->parent = this;
	return node_;
}


bool node::RemoveChild( node* removeThis )
{
	if ( removeThis->parent != this )
	{	
		assert( 0 );
		return false;
	}

	if ( removeThis->next )
		removeThis->next->prev = removeThis->prev;
	else
		lastChild = removeThis->prev;

	if ( removeThis->prev )
		removeThis->prev->next = removeThis->next;
	else
		firstChild = removeThis->next;

	delete removeThis;
	return true;
}

const node* node::FirstChild( const char * _value ) const
{
	const node* node_;
	for ( node_ = firstChild; node_; node_ = node_->next )
	{
		if ( strcmp( node_->Value(), _value ) == 0 )
			return node_;
	}
	return 0;
}


const node* node::LastChild( const char * _value ) const
{
	const node* node_;
	for ( node_ = lastChild; node_; node_ = node_->prev )
	{
		if ( strcmp( node_->Value(), _value ) == 0 )
			return node_;
	}
	return 0;
}


const node* node::IterateChildren( const node* previous ) const
{
	if ( !previous )
	{
		return FirstChild();
	}
	else
	{
		assert( previous->parent == this );
		return previous->NextSibling();
	}
}


const node* node::IterateChildren( const char * val, const node* previous ) const
{
	if ( !previous )
	{
		return FirstChild( val );
	}
	else
	{
		assert( previous->parent == this );
		return previous->NextSibling( val );
	}
}


const node* node::NextSibling( const char * _value ) const 
{
	const node* node_;
	for ( node_ = next; node_; node_ = node_->next )
	{
		if ( strcmp( node_->Value(), _value ) == 0 )
			return node_;
	}
	return 0;
}


const node* node::PreviousSibling( const char * _value ) const
{
	const node* node_;
	for ( node_ = prev; node_; node_ = node_->prev )
	{
		if ( strcmp( node_->Value(), _value ) == 0 )
			return node_;
	}
	return 0;
}


void element::RemoveAttribute( const char * name )
{
    #ifdef TIXML_USE_STL
	TIXML_STRING str( name );
	attribute* node_ = attribute_Set.Find( str );
	#else
	attribute* node_ = attribute_Set.Find( name );
	#endif
	if ( node_ )
	{
		attribute_Set.Remove( node_ );
		delete node_;
	}
}

const element* node::FirstChildElement() const
{
	const node* node_;

	for (	node_ = FirstChild();
			node_;
			node_ = node_->NextSibling() )
	{
		if ( node_->ToElement() )
			return node_->ToElement();
	}
	return 0;
}


const element* node::FirstChildElement( const char * _value ) const
{
	const node* node_;

	for (	node_ = FirstChild( _value );
			node_;
			node_ = node_->NextSibling( _value ) )
	{
		if ( node_->ToElement() )
			return node_->ToElement();
	}
	return 0;
}


const element* node::NextSiblingElement() const
{
	const node* node_;

	for (	node_ = NextSibling();
			node_;
			node_ = node_->NextSibling() )
	{
		if ( node_->ToElement() )
			return node_->ToElement();
	}
	return 0;
}


const element* node::NextSiblingElement( const char * _value ) const
{
	const node* node_;

	for (	node_ = NextSibling( _value );
			node_;
			node_ = node_->NextSibling( _value ) )
	{
		if ( node_->ToElement() )
			return node_->ToElement();
	}
	return 0;
}


const document* node::GetDocument() const
{
	const node* node_;

	for( node_ = this; node_; node_ = node_->parent )
	{
		if ( node_->ToDocument() )
			return node_->ToDocument();
	}
	return 0;
}


element::element (const char * _value)
	: node( node::ELEMENT )
{
	firstChild = lastChild = 0;
	value = _value;
}


#ifdef TIXML_USE_STL
element::element( const std::string& _value ) 
	: node( node::ELEMENT )
{
	firstChild = lastChild = 0;
	value = _value;
}
#endif


element::element( const element& copy)
	: node( node::ELEMENT )
{
	firstChild = lastChild = 0;
	copy.CopyTo( this );	
}


void element::operator=( const element& base_ )
{
	ClearThis();
	base_.CopyTo( this );
}


element::~element()
{
	ClearThis();
}


void element::ClearThis()
{
	Clear();
	while( attribute_Set.First() )
	{
		attribute* node_ = attribute_Set.First();
		attribute_Set.Remove( node_ );
		delete node_;
	}
}


const char* element::Attribute( const char* name ) const
{
	const attribute* node_ = attribute_Set.Find( name );
	if ( node_ )
		return node_->Value();
	return 0;
}


#ifdef TIXML_USE_STL
const std::string* element::Attribute( const std::string& name ) const
{
	const attribute* node_ = attribute_Set.Find( name );
	if ( node_ )
		return &node_->ValueStr();
	return 0;
}
#endif


const char* element::Attribute( const char* name, int* i ) const
{
	const char* s = Attribute( name );
	if ( i )
	{
		if ( s ) {
			*i = atoi( s );
		}
		else {
			*i = 0;
		}
	}
	return s;
}


#ifdef TIXML_USE_STL
const std::string* element::Attribute( const std::string& name, int* i ) const
{
	const std::string* s = Attribute( name );
	if ( i )
	{
		if ( s ) {
			*i = atoi( s->c_str() );
		}
		else {
			*i = 0;
		}
	}
	return s;
}
#endif


const char* element::Attribute( const char* name, double* d ) const
{
	const char* s = Attribute( name );
	if ( d )
	{
		if ( s ) {
			*d = atof( s );
		}
		else {
			*d = 0;
		}
	}
	return s;
}


#ifdef TIXML_USE_STL
const std::string* element::Attribute( const std::string& name, double* d ) const
{
	const std::string* s = Attribute( name );
	if ( d )
	{
		if ( s ) {
			*d = atof( s->c_str() );
		}
		else {
			*d = 0;
		}
	}
	return s;
}
#endif


int element::QueryIntAttribute( const char* name, int* ival ) const
{
	const attribute* node_ = attribute_Set.Find( name );
	if ( !node_ )
		return TIXML_NO_ATTRIBUTE;
	return node_->QueryIntValue( ival );
}


#ifdef TIXML_USE_STL
int element::QueryIntAttribute( const std::string& name, int* ival ) const
{
	const attribute* node_ = attribute_Set.Find( name );
	if ( !node_ )
		return TIXML_NO_ATTRIBUTE;
	return node_->QueryIntValue( ival );
}
#endif


int element::QueryDoubleAttribute( const char* name, double* dval ) const
{
	const attribute* node_ = attribute_Set.Find( name );
	if ( !node_ )
		return TIXML_NO_ATTRIBUTE;
	return node_->QueryDoubleValue( dval );
}


#ifdef TIXML_USE_STL
int element::QueryDoubleAttribute( const std::string& name, double* dval ) const
{
	const attribute* node_ = attribute_Set.Find( name );
	if ( !node_ )
		return TIXML_NO_ATTRIBUTE;
	return node_->QueryDoubleValue( dval );
}
#endif


void element::SetAttribute( const char * name, int val )
{	
	char buf[64];
	#if defined(TIXML_SNPRINTF)		
		TIXML_SNPRINTF( buf, sizeof(buf), "%d", val );
	#else
		sprintf( buf, "%d", val );
	#endif
	SetAttribute( name, buf );
}


#ifdef TIXML_USE_STL
void element::SetAttribute( const std::string& name, int val )
{	
   std::ostringstream oss;
   oss << val;
   SetAttribute( name, oss.str() );
}
#endif


void element::SetDoubleAttribute( const char * name, double val )
{	
	char buf[256];
	#if defined(TIXML_SNPRINTF)		
		TIXML_SNPRINTF( buf, sizeof(buf), "%f", val );
	#else
		sprintf( buf, "%f", val );
	#endif
	SetAttribute( name, buf );
}


void element::SetAttribute( const char * cname, const char * cvalue )
{
    #ifdef TIXML_USE_STL
	TIXML_STRING _name( cname );
	TIXML_STRING _value( cvalue );
	#else
	const char* _name = cname;
	const char* _value = cvalue;
	#endif

	attribute* node_ = attribute_Set.Find( _name );
	if ( node_ )
	{
		node_->SetValue( _value );
		return;
	}

	attribute* attrib = new attribute( cname, cvalue );
	if ( attrib )
	{
		attribute_Set.Add( attrib );
	}
	else
	{
		document* document_ = GetDocument();
		if ( document_ ) document_->SetError( TIXML_ERROR_OUT_OF_MEMORY, 0, 0, TIXML_ENCODING_UNKNOWN );
	}
}


#ifdef TIXML_USE_STL
void element::SetAttribute( const std::string& name, const std::string& _value )
{
	attribute* node_ = attribute_Set.Find( name );
	if ( node_ )
	{
		node_->SetValue( _value );
		return;
	}

	attribute* attrib = new attribute( name, _value );
	if ( attrib )
	{
		attribute_Set.Add( attrib );
	}
	else
	{
		document* document_ = GetDocument();
		if ( document_ ) document_->SetError( TIXML_ERROR_OUT_OF_MEMORY, 0, 0, TIXML_ENCODING_UNKNOWN );
	}
}
#endif


void element::Print( FILE* cfile, int depth ) const
{
	int i;
	assert( cfile );
	for ( i=0; i<depth; i++ ) {
		fprintf( cfile, "    " );
	}

	fprintf( cfile, "<%s", value.c_str() );

	const attribute* attrib;
	for ( attrib = attribute_Set.First(); attrib; attrib = attrib->Next() )
	{
		fprintf( cfile, " " );
		attrib->Print( cfile, depth );
	}

	// There are 3 different formatting approaches:
	// 1) An element_ without children is printed as a <foo /> node_
	// 2) An element_ with only a text_ child is printed as <foo> text_ </foo>
	// 3) An element_ with children is printed on multiple lines.
	node* node_;
	if ( !firstChild )
	{
		fprintf( cfile, " />" );
	}
	else if ( firstChild == lastChild && firstChild->ToText() )
	{
		fprintf( cfile, ">" );
		firstChild->Print( cfile, depth + 1 );
		fprintf( cfile, "</%s>", value.c_str() );
	}
	else
	{
		fprintf( cfile, ">" );

		for ( node_ = firstChild; node_; node_=node_->NextSibling() )
		{
			if ( !node_->ToText() )
			{
				fprintf( cfile, "\n" );
			}
			node_->Print( cfile, depth+1 );
		}
		fprintf( cfile, "\n" );
		for( i=0; i<depth; ++i ) {
			fprintf( cfile, "    " );
		}
		fprintf( cfile, "</%s>", value.c_str() );
	}
}


void element::CopyTo( element* target ) const
{
	// superclass:
	node::CopyTo( target );

	// Element class: 
	// Clone the attribute_s, then clone the children.
	const attribute* attribute_ = 0;
	for(	attribute_ = attribute_Set.First();
	attribute_;
	attribute_ = attribute_->Next() )
	{
		target->SetAttribute( attribute_->Name(), attribute_->Value() );
	}

	node* node_ = 0;
	for ( node_ = firstChild; node_; node_ = node_->NextSibling() )
	{
		target->LinkEndChild( node_->Clone() );
	}
}

bool element::Accept( visitor* visitor_ ) const
{
	if ( visitor_->VisitEnter( *this, attribute_Set.First() ) ) 
	{
		for ( const node* node_=FirstChild(); node_; node_=node_->NextSibling() )
		{
			if ( !node_->Accept( visitor_ ) )
				break;
		}
	}
	return visitor_->VisitExit( *this );
}


node* element::Clone() const
{
	element* clone = new element( Value() );
	if ( !clone )
		return 0;

	CopyTo( clone );
	return clone;
}


const char* element::GetText() const
{
	const node* child = this->FirstChild();
	if ( child ) {
		const text* childText = child->ToText();
		if ( childText ) {
			return childText->Value();
		}
	}
	return 0;
}


document::document() : node( node::DOCUMENT )
{
	tabsize = 4;
	useMicrosoftBOM = false;
	ClearError();
}

document::document( const char * document_Name ) : node( node::DOCUMENT )
{
	tabsize = 4;
	useMicrosoftBOM = false;
	value = document_Name;
	ClearError();
}


#ifdef TIXML_USE_STL
document::document( const std::string& document_Name ) : node( node::DOCUMENT )
{
	tabsize = 4;
	useMicrosoftBOM = false;
    value = document_Name;
	ClearError();
}
#endif


document::document( const document& copy ) : node( node::DOCUMENT )
{
	copy.CopyTo( this );
}


void document::operator=( const document& copy )
{
	Clear();
	copy.CopyTo( this );
}


bool document::LoadFile( encoding encoding_ )
{
	// See STL_STRING_BUG below.
	//StringToBuffer buf( value );

	return LoadFile( Value(), encoding_ );
}


bool document::SaveFile() const
{
	// See STL_STRING_BUG below.
//	StringToBuffer buf( value );
//
//	if ( buf.buffer && SaveFile( buf.buffer ) )
//		return true;
//
//	return false;
	return SaveFile( Value() );
}

bool document::LoadFile( const char* _filename, encoding encoding_ )
{
	// There was a really terrifying little bug here. The code:
	//		value = filename
	// in the STL case, cause the assignment method of the std::string to
	// be called. What is strange, is that the std::string had the same
	// address as it's c_str() method, and so bad things happen. Looks
	// like a bug in the Microsoft STL implementation.
	// Add an extra string to avoid the crash.
	TIXML_STRING filename( _filename );
	value = filename;

	// reading in binary mode so that tinyxml can normalize the EOL
	FILE* file = fopen( value.c_str (), "rb" );	

	if ( file )
	{
		bool result = LoadFile( file, encoding_ );
		fclose( file );
		return result;
	}
	else
	{
		SetError( TIXML_ERROR_OPENING_FILE, 0, 0, TIXML_ENCODING_UNKNOWN );
		return false;
	}
}

bool document::LoadFile( FILE* file, encoding encoding_ )
{
	if ( !file ) 
	{
		SetError( TIXML_ERROR_OPENING_FILE, 0, 0, TIXML_ENCODING_UNKNOWN );
		return false;
	}

	// Delete the existing data:
	Clear();
	location.Clear();

	// Get the file size, so we can pre-allocate the string. HUGE speed impact.
	long length = 0;
	fseek( file, 0, SEEK_END );
	length = ftell( file );
	fseek( file, 0, SEEK_SET );

	// Strange case, but good to handle_ up front.
	if ( length == 0 )
	{
		SetError( TIXML_ERROR_DOCUMENT_EMPTY, 0, 0, TIXML_ENCODING_UNKNOWN );
		return false;
	}

	// If we have a file, assume it is all one big XML file, and read it in.
	// The document_ parser may decide the document_ ends sooner than the entire file, however.
	TIXML_STRING data;
	data.reserve( length );

	// Subtle bug here. TinyXml did use fgets. But from the XML spec:
	// 2.11 End-of-Line Handling
	// <snip>
	// <quote>
	// ...the XML processor MUST behave as if it normalized all line breaks in external 
	// parsed entities (including the document_ entity) on input, before parsing, by translating 
	// both the two-character sequence #xD #xA and any #xD that is not followed by #xA to 
	// a single #xA character.
	// </quote>
	//
	// It is not clear fgets does that, and certainly isn't clear it works cross platform. 
	// Generally, you expect fgets to translate from the convention of the OS to the c/unix
	// convention, and not work generally.

	/*
	while( fgets( buf, sizeof(buf), file ) )
	{
		data += buf;
	}
	*/

	char* buf = new char[ length+1 ];
	buf[0] = 0;

	if ( fread( buf, length, 1, file ) != 1 ) {
		delete [] buf;
		SetError( TIXML_ERROR_OPENING_FILE, 0, 0, TIXML_ENCODING_UNKNOWN );
		return false;
	}

	const char* lastPos = buf;
	const char* p = buf;

	buf[length] = 0;
	while( *p ) {
		assert( p < (buf+length) );
		if ( *p == 0xa ) {
			// Newline character. No special rules for this. Append all the characters
			// since the last string, and include the newline.
			data.append( lastPos, (p-lastPos+1) );	// append, include the newline
			++p;									// move past the newline
			lastPos = p;							// and point to the new buffer (may be 0)
			assert( p <= (buf+length) );
		}
		else if ( *p == 0xd ) {
			// Carriage return. Append what we have so far, then
			// handle_ moving forward in the buffer.
			if ( (p-lastPos) > 0 ) {
				data.append( lastPos, p-lastPos );	// do not add the CR
			}
			data += (char)0xa;						// a proper newline

			if ( *(p+1) == 0xa ) {
				// Carriage return - new line sequence
				p += 2;
				lastPos = p;
				assert( p <= (buf+length) );
			}
			else {
				// it was followed by something else...that is presumably characters again.
				++p;
				lastPos = p;
				assert( p <= (buf+length) );
			}
		}
		else {
			++p;
		}
	}
	// Handle any left over characters.
	if ( p-lastPos ) {
		data.append( lastPos, p-lastPos );
	}		
	delete [] buf;
	buf = 0;

	Parse( data.c_str(), 0, encoding_ );

	if (  Error() )
        return false;
    else
		return true;
}


bool document::SaveFile( const char * filename ) const
{
	// The old c stuff lives on...
	FILE* fp = fopen( filename, "w" );
	if ( fp )
	{
		bool result = SaveFile( fp );
		fclose( fp );
		return result;
	}
	return false;
}


bool document::SaveFile( FILE* fp ) const
{
	if ( useMicrosoftBOM ) 
	{
		const unsigned char TIXML_UTF_LEAD_0 = 0xefU;
		const unsigned char TIXML_UTF_LEAD_1 = 0xbbU;
		const unsigned char TIXML_UTF_LEAD_2 = 0xbfU;

		fputc( TIXML_UTF_LEAD_0, fp );
		fputc( TIXML_UTF_LEAD_1, fp );
		fputc( TIXML_UTF_LEAD_2, fp );
	}
	Print( fp, 0 );
	return (ferror(fp) == 0);
}


void document::CopyTo( document* target ) const
{
	node::CopyTo( target );

	target->error = error;
	target->errorDesc = errorDesc.c_str ();

	node* node_ = 0;
	for ( node_ = firstChild; node_; node_ = node_->NextSibling() )
	{
		target->LinkEndChild( node_->Clone() );
	}	
}


node* document::Clone() const
{
	document* clone = new document();
	if ( !clone )
		return 0;

	CopyTo( clone );
	return clone;
}


void document::Print( FILE* cfile, int depth ) const
{
	assert( cfile );
	for ( const node* node_=FirstChild(); node_; node_=node_->NextSibling() )
	{
		node_->Print( cfile, depth );
		fprintf( cfile, "\n" );
	}
}


bool document::Accept( visitor* visitor_ ) const
{
	if ( visitor_->VisitEnter( *this ) )
	{
		for ( const node* node_=FirstChild(); node_; node_=node_->NextSibling() )
		{
			if ( !node_->Accept( visitor_ ) )
				break;
		}
	}
	return visitor_->VisitExit( *this );
}


const attribute* attribute::Next() const
{
	// We are using knowledge of the sentinel. The sentinel
	// have a value or name.
	if ( next->value.empty() && next->name.empty() )
		return 0;
	return next;
}

/*
attribute* attribute::Next()
{
	// We are using knowledge of the sentinel. The sentinel
	// have a value or name.
	if ( next->value.empty() && next->name.empty() )
		return 0;
	return next;
}
*/

const attribute* attribute::Previous() const
{
	// We are using knowledge of the sentinel. The sentinel
	// have a value or name.
	if ( prev->value.empty() && prev->name.empty() )
		return 0;
	return prev;
}

/*
attribute* attribute::Previous()
{
	// We are using knowledge of the sentinel. The sentinel
	// have a value or name.
	if ( prev->value.empty() && prev->name.empty() )
		return 0;
	return prev;
}
*/

void attribute::Print( FILE* cfile, int /*depth*/, TIXML_STRING* str ) const
{
	TIXML_STRING n, v;

	PutString( name, &n );
	PutString( value, &v );

	if (value.find ('\"') == TIXML_STRING::npos) {
		if ( cfile ) {
		fprintf (cfile, "%s=\"%s\"", n.c_str(), v.c_str() );
		}
		if ( str ) {
			(*str) += n; (*str) += "=\""; (*str) += v; (*str) += "\"";
		}
	}
	else {
		if ( cfile ) {
		fprintf (cfile, "%s='%s'", n.c_str(), v.c_str() );
		}
		if ( str ) {
			(*str) += n; (*str) += "='"; (*str) += v; (*str) += "'";
		}
	}
}


int attribute::QueryIntValue( int* ival ) const
{
	if ( sscanf( value.c_str(), "%d", ival ) == 1 )
		return TIXML_SUCCESS;
	return TIXML_WRONG_TYPE;
}

int attribute::QueryDoubleValue( double* dval ) const
{
	if ( sscanf( value.c_str(), "%lf", dval ) == 1 )
		return TIXML_SUCCESS;
	return TIXML_WRONG_TYPE;
}

void attribute::SetIntValue( int _value )
{
	char buf [64];
	#if defined(TIXML_SNPRINTF)		
		TIXML_SNPRINTF(buf, sizeof(buf), "%d", _value);
	#else
		sprintf (buf, "%d", _value);
	#endif
	SetValue (buf);
}

void attribute::SetDoubleValue( double _value )
{
	char buf [256];
	#if defined(TIXML_SNPRINTF)		
		TIXML_SNPRINTF( buf, sizeof(buf), "%lf", _value);
	#else
		sprintf (buf, "%lf", _value);
	#endif
	SetValue (buf);
}

int attribute::IntValue() const
{
	return atoi (value.c_str ());
}

double  attribute::DoubleValue() const
{
	return atof (value.c_str ());
}


comment::comment( const comment& copy ) : node( node::COMMENT )
{
	copy.CopyTo( this );
}


void comment::operator=( const comment& base_ )
{
	Clear();
	base_.CopyTo( this );
}


void comment::Print( FILE* cfile, int depth ) const
{
	assert( cfile );
	for ( int i=0; i<depth; i++ )
	{
		fprintf( cfile,  "    " );
	}
	fprintf( cfile, "<!--%s-->", value.c_str() );
}


void comment::CopyTo( comment* target ) const
{
	node::CopyTo( target );
}


bool comment::Accept( visitor* visitor_ ) const
{
	return visitor_->Visit( *this );
}


node* comment::Clone() const
{
	comment* clone = new comment();

	if ( !clone )
		return 0;

	CopyTo( clone );
	return clone;
}


void text::Print( FILE* cfile, int depth ) const
{
	assert( cfile );
	if ( cdata )
	{
		int i;
		fprintf( cfile, "\n" );
		for ( i=0; i<depth; i++ ) {
			fprintf( cfile, "    " );
		}
		fprintf( cfile, "<![CDATA[%s]]>\n", value.c_str() );	// unformatted output
	}
	else
	{
		TIXML_STRING buffer;
		PutString( value, &buffer );
		fprintf( cfile, "%s", buffer.c_str() );
	}
}


void text::CopyTo( text* target ) const
{
	node::CopyTo( target );
	target->cdata = cdata;
}


bool text::Accept( visitor* visitor_ ) const
{
	return visitor_->Visit( *this );
}


node* text::Clone() const
{	
	text* clone = 0;
	clone = new text( "" );

	if ( !clone )
		return 0;

	CopyTo( clone );
	return clone;
}


declaration::declaration( const char * _version,
									const char * _encoding_,
									const char * _standalone )
	: node( node::DECLARATION )
{
	version = _version;
	encoding_ = _encoding_;
	standalone = _standalone;
}


#ifdef TIXML_USE_STL
declaration::declaration(	const std::string& _version,
									const std::string& _encoding_,
									const std::string& _standalone )
	: node( node::DECLARATION )
{
	version = _version;
	encoding_ = _encoding_;
	standalone = _standalone;
}
#endif


declaration::declaration( const declaration& copy )
	: node( node::DECLARATION )
{
	copy.CopyTo( this );	
}


void declaration::operator=( const declaration& copy )
{
	Clear();
	copy.CopyTo( this );
}


void declaration::Print( FILE* cfile, int /*depth*/, TIXML_STRING* str ) const
{
	if ( cfile ) fprintf( cfile, "<?xml " );
	if ( str )	 (*str) += "<?xml ";

	if ( !version.empty() ) {
		if ( cfile ) fprintf (cfile, "version=\"%s\" ", version.c_str ());
		if ( str ) { (*str) += "version=\""; (*str) += version; (*str) += "\" "; }
	}
	if ( !encoding_.empty() ) {
		if ( cfile ) fprintf (cfile, "encoding_=\"%s\" ", encoding_.c_str ());
		if ( str ) { (*str) += "encoding_=\""; (*str) += encoding_; (*str) += "\" "; }
	}
	if ( !standalone.empty() ) {
		if ( cfile ) fprintf (cfile, "standalone=\"%s\" ", standalone.c_str ());
		if ( str ) { (*str) += "standalone=\""; (*str) += standalone; (*str) += "\" "; }
	}
	if ( cfile ) fprintf( cfile, "?>" );
	if ( str )	 (*str) += "?>";
}


void declaration::CopyTo( declaration* target ) const
{
	node::CopyTo( target );

	target->version = version;
	target->encoding_ = encoding_;
	target->standalone = standalone;
}


bool declaration::Accept( visitor* visitor_ ) const
{
	return visitor_->Visit( *this );
}


node* declaration::Clone() const
{	
	declaration* clone = new declaration();

	if ( !clone )
		return 0;

	CopyTo( clone );
	return clone;
}


void unknown::Print( FILE* cfile, int depth ) const
{
	for ( int i=0; i<depth; i++ )
		fprintf( cfile, "    " );
	fprintf( cfile, "<%s>", value.c_str() );
}


void unknown::CopyTo( unknown* target ) const
{
	node::CopyTo( target );
}


bool unknown::Accept( visitor* visitor_ ) const
{
	return visitor_->Visit( *this );
}


node* unknown::Clone() const
{
	unknown* clone = new unknown();

	if ( !clone )
		return 0;

	CopyTo( clone );
	return clone;
}


attributeSet::attributeSet()
{
	sentinel.next = &sentinel;
	sentinel.prev = &sentinel;
}


attributeSet::~attributeSet()
{
	assert( sentinel.next == &sentinel );
	assert( sentinel.prev == &sentinel );
}


void attributeSet::Add( attribute* addMe )
{
    #ifdef TIXML_USE_STL
	assert( !Find( TIXML_STRING( addMe->Name() ) ) );	// Shouldn't be multiply adding to the set.
	#else
	assert( !Find( addMe->Name() ) );	// Shouldn't be multiply adding to the set.
	#endif

	addMe->next = &sentinel;
	addMe->prev = sentinel.prev;

	sentinel.prev->next = addMe;
	sentinel.prev      = addMe;
}

void attributeSet::Remove( attribute* removeMe )
{
	attribute* node_;

	for( node_ = sentinel.next; node_ != &sentinel; node_ = node_->next )
	{
		if ( node_ == removeMe )
		{
			node_->prev->next = node_->next;
			node_->next->prev = node_->prev;
			node_->next = 0;
			node_->prev = 0;
			return;
		}
	}
	assert( 0 );		// we tried to remove a non-linked attribute_.
}


#ifdef TIXML_USE_STL
const attribute* attributeSet::Find( const std::string& name ) const
{
	for( const attribute* node_ = sentinel.next; node_ != &sentinel; node_ = node_->next )
	{
		if ( node_->name == name )
			return node_;
	}
	return 0;
}

/*
attribute*	attributeSet::Find( const std::string& name )
{
	for( attribute* node_ = sentinel.next; node_ != &sentinel; node_ = node_->next )
	{
		if ( node_->name == name )
			return node_;
	}
	return 0;
}
*/
#endif


const attribute* attributeSet::Find( const char* name ) const
{
	for( const attribute* node_ = sentinel.next; node_ != &sentinel; node_ = node_->next )
	{
		if ( strcmp( node_->name.c_str(), name ) == 0 )
			return node_;
	}
	return 0;
}

/*
attribute*	attributeSet::Find( const char* name )
{
	for( attribute* node_ = sentinel.next; node_ != &sentinel; node_ = node_->next )
	{
		if ( strcmp( node_->name.c_str(), name ) == 0 )
			return node_;
	}
	return 0;
}
*/

#ifdef TIXML_USE_STL	
std::istream& operator>> (std::istream & in, node & base_)
{
	TIXML_STRING tag;
	tag.reserve( 8 * 1000 );
	base_.StreamIn( &in, &tag );

	base_.Parse( tag.c_str(), 0, TIXML_DEFAULT_ENCODING );
	return in;
}
#endif


#ifdef TIXML_USE_STL	
std::ostream& operator<< (std::ostream & out, const node & base_)
{
	printer printer_;
	printer_.SetStreamPrinting();
	base_.Accept( &printer_ );
	out << printer_.Str();

	return out;
}


std::string& operator<< (std::string& out, const node& base_ )
{
	printer printer_;
	printer_.SetStreamPrinting();
	base_.Accept( &printer_ );
	out.append( printer_.Str() );

	return out;
}
#endif


handle handle::FirstChild() const
{
	if ( node_ )
	{
		node* child = node_->FirstChild();
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


handle handle::FirstChild( const char * value ) const
{
	if ( node_ )
	{
		node* child = node_->FirstChild( value );
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


handle handle::FirstChildElement() const
{
	if ( node_ )
	{
		element* child = node_->FirstChildElement();
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


handle handle::FirstChildElement( const char * value ) const
{
	if ( node_ )
	{
		element* child = node_->FirstChildElement( value );
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


handle handle::Child( int count ) const
{
	if ( node_ )
	{
		int i;
		node* child = node_->FirstChild();
		for (	i=0;
				child && i<count;
				child = child->NextSibling(), ++i )
		{
			// nothing
		}
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


handle handle::Child( const char* value, int count ) const
{
	if ( node_ )
	{
		int i;
		node* child = node_->FirstChild( value );
		for (	i=0;
				child && i<count;
				child = child->NextSibling( value ), ++i )
		{
			// nothing
		}
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


handle handle::ChildElement( int count ) const
{
	if ( node_ )
	{
		int i;
		element* child = node_->FirstChildElement();
		for (	i=0;
				child && i<count;
				child = child->NextSiblingElement(), ++i )
		{
			// nothing
		}
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


handle handle::ChildElement( const char* value, int count ) const
{
	if ( node_ )
	{
		int i;
		element* child = node_->FirstChildElement( value );
		for (	i=0;
				child && i<count;
				child = child->NextSiblingElement( value ), ++i )
		{
			// nothing
		}
		if ( child )
			return handle( child );
	}
	return handle( 0 );
}


bool printer::VisitEnter( const document& )
{
	return true;
}

bool printer::VisitExit( const document& )
{
	return true;
}

bool printer::VisitEnter( const element& element_, const attribute* firstAttribute )
{
	DoIndent();
	buffer += "<";
	buffer += element_.Value();

	for( const attribute* attrib = firstAttribute; attrib; attrib = attrib->Next() )
	{
		buffer += " ";
		attrib->Print( 0, 0, &buffer );
	}

	if ( !element_.FirstChild() ) 
	{
		buffer += " />";
		DoLineBreak();
	}
	else 
	{
		buffer += ">";
		if (    element_.FirstChild()->ToText()
			  && element_.LastChild() == element_.FirstChild()
			  && element_.FirstChild()->ToText()->CDATA() == false )
		{
			simpleTextPrint = true;
			// no DoLineBreak()!
		}
		else
		{
			DoLineBreak();
		}
	}
	++depth;	
	return true;
}


bool printer::VisitExit( const element& element_ )
{
	--depth;
	if ( !element_.FirstChild() ) 
	{
		// nothing.
	}
	else 
	{
		if ( simpleTextPrint )
		{
			simpleTextPrint = false;
		}
		else
		{
			DoIndent();
		}
		buffer += "</";
		buffer += element_.Value();
		buffer += ">";
		DoLineBreak();
	}
	return true;
}


bool printer::Visit( const text& text_ )
{
	if ( text_.CDATA() )
	{
		DoIndent();
		buffer += "<![CDATA[";
		buffer += text_.Value();
		buffer += "]]>";
		DoLineBreak();
	}
	else if ( simpleTextPrint )
	{
		buffer += text_.Value();
	}
	else
	{
		DoIndent();
		buffer += text_.Value();
		DoLineBreak();
	}
	return true;
}


bool printer::Visit( const declaration& declaration_ )
{
	DoIndent();
	declaration_.Print( 0, 0, &buffer );
	DoLineBreak();
	return true;
}


bool printer::Visit( const comment& comment_ )
{
	DoIndent();
	buffer += "<!--";
	buffer += comment_.Value();
	buffer += "-->";
	DoLineBreak();
	return true;
}


bool printer::Visit( const unknown& unknown_ )
{
	DoIndent();
	buffer += "<";
	buffer += unknown_.Value();
	buffer += ">";
	DoLineBreak();
	return true;
}

};
