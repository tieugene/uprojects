
#include <QApplication>
#include <QWidget>

#include "dsingleapplication.h"

int main(int argc, char *argv[]) {

  QApplication app(argc, argv);

  DSingleApplication instance( "MY_APP" );
  
  if ( instance.isRunning() ) {
    instance.sendMessage( "Hey, i'm the other instance" );
    return 0;
  }

  QWidget w;

  // w should have a slot to receive messages
  //QObject::connect( &instance, SIGNAL( messageReceived(const QString &) ), 
  //                  &w,   SLOT( onOtherInstanceMessage(const QString &) ) );

  w.show();

  return app.exec();
}
