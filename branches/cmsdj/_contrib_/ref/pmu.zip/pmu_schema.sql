CREATE TABLE class_pmu (
  id int(11) NOT NULL auto_increment COMMENT 'PK',
  `name` varchar(512) NOT NULL COMMENT 'Наименование',
  `code` varchar(20) NOT NULL COMMENT 'Код',
  parent_id int(11) default NULL COMMENT 'Вышестоящий объект',
  parent_code varchar(20) default NULL COMMENT 'Код вышестоящего объекта',
  node_count smallint(6) NOT NULL default '0' COMMENT 'Количество вложенных в текущую ветку',
  additional_info text COMMENT 'Дополнительная информация',
  PRIMARY KEY  (id),
  KEY parent_id (parent_id),
  KEY parent_code (parent_code)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='ОК Простые медицинские услуги';

ALTER TABLE `class_pmu`
  ADD CONSTRAINT class_pmu_ibfk_1 FOREIGN KEY (parent_id) REFERENCES class_pmu (id);
