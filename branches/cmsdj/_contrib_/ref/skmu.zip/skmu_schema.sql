CREATE TABLE class_skmu (
  id int(11) NOT NULL auto_increment COMMENT 'PK',
  `name` varchar(512) NOT NULL COMMENT 'Наименование',
  `code` varchar(20) NOT NULL COMMENT 'Код',
  parent_id int(11) default NULL COMMENT 'Вышестоящий объект',
  parent_code varchar(20) default NULL COMMENT 'Код вышестоящего объекта',
  node_count smallint(6) NOT NULL default '0' COMMENT 'Количество вложенных в текущую ветку',
  additional_info text COMMENT 'Дополнительная информация',
  PRIMARY KEY  (id),
  KEY parent_id (parent_id),
  KEY parent_code (parent_code)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='ОК Сложные и комплексные медицинские услуги';

ALTER TABLE `class_skmu`
  ADD CONSTRAINT class_skmu_ibfk_1 FOREIGN KEY (parent_id) REFERENCES class_skmu (id);
