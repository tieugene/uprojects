# -*- coding: utf-8 -*-
from reg.regsys.cards import Card
from reg.regsys.uprofile import UserProfile

card_key = sys.argv[1]
room_id = int(sys.argv[2])

