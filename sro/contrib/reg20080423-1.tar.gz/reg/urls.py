from django.conf.urls.defaults import *

urlpatterns = patterns('',
    # Example:
    # (r'^reg/', include('reg.foo.urls')),

    # Uncomment this for admin:
    (r'^admin/', include('django.contrib.admin.urls')),
    # WARNING: remove this in production server
    #(r'^site_media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': '/home/cl/Projects/schreg/reg/regsys/media/'}),
    #(r'^site_media2/(?P<path>.*)$', 'django.views.static.serve', {'document_root': '/home/cl/media_sysreg/'}),
    #
    (r'^$', 'reg.regsys.views.index'), 
    (r'^my_login/$', 'reg.regsys.views.my_login'),
    (r'^my_logout/$', 'reg.regsys.views.my_logout'),
    (r'^error/$', 'reg.regsys.views.error'),
    
    #
    (r'^card/new/$', 'reg.regsys.views.forms.new_card'),
    (r'^card/wait_new/$', 'reg.regsys.views.cards.wait_new'),
    (r'^card/(?P<card_id>\d+)/replace_card/$', 'reg.regsys.views.cards.replace_card'),
    (r'^card/(?P<card_id>\d+)/replace/$', 'reg.regsys.views.cards.wait_replace'),
    
    (r'^card/list/$', 'reg.regsys.views.cards.show_card_list'),
    (r'^card/(?P<card_id>\d+)/$', 'reg.regsys.views.cards.detail'),
    (r'^card/(?P<card_id>\d+)/invalidate/$', 'reg.regsys.views.cards.cancel_card'),
    #
    (r'^room/student/present_list/$', 'reg.regsys.views.reports.show_students_in_room'),
    (r'^room/student/away_list/$', 'reg.regsys.views.reports.show_students_away_room'),
    (r'^room/new/$', 'reg.regsys.views.forms.new_room'),
    (r'^room/list/$', 'reg.regsys.views.reports.show_room_list'),
    (r'^room/(?P<room_id>\d+)/$', 'reg.regsys.views.rooms.detail'),
    (r'^room/(?P<room_id>\d+)/log/$', 'reg.regsys.views.rooms.show_room_journal'),
    
    #
    (r'^profile/(?P<profile_id>\d+)/$', 'reg.regsys.views.profile.detail'),
    (r'^profile/(?P<profile_id>\d+)/edit/$', 'reg.regsys.views.forms.edit_profile'),
    (r'^profile/(?P<profile_id>\d+)/log/$', 'reg.regsys.views.reports.show_user_journal'),
    (r'^profile/(?P<profile_id>\d+)/syslogev/$', 'reg.regsys.views.profile.mksysrec'),
    #
    (r'^teachers/status/$', 'reg.regsys.views.reports.teachers_status'),
    #
    (r'^grade/list/$', 'reg.regsys.views.reports.show_students_list'),
    (r'^my_students/$', 'reg.regsys.views.profile.show_my_students'),
)
