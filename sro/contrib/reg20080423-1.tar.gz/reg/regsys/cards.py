# -*- coding: utf-8 -*-
from django.db import models, connection
from reg.regsys import uprofile, myfields

class PendingManager(models.Manager):
    def deletePending(self):
        c = connection.cursor()
        c.execute("""DELETE FROM pending_card""")

    def getPendingCard(self):
        try:
            r = PendingRegistrationCard.objects.latest('id')
            return (True, r)
        except:
            return (False, None)

class PendingRegistrationCard(models.Model):
    card_key = models.CharField(maxlength=10, default='', unique=True)
    read_from_room_id =  models.IntegerField(default=0)
    known = models.BooleanField(default=False)
    found_id = models.IntegerField(default=0)
    
    objects = PendingManager()
    
    class Meta:
        db_table = 'pending_card'
        
    class Admin:
        pass
        
    def isPending(self):
        return PendingRegistrationCard.objects.count() > 0
    isPending = classmethod(isPending)
            
#class CardManager(models.Manager):
#    pass
    
class Card(models.Model):
    card_key = models.CharField(maxlength=10, default='', unique=True)
    owner = models.ForeignKey(uprofile.UserProfile, blank=True, related_name="owned_cards")
    valid = models.BooleanField(default=True, db_index=True)
    logged = models.BooleanField(default=False, db_index=True)
    room_id = models.IntegerField(db_index=True, default=0)
    log_id = models.IntegerField(default=0)
    event = models.DateTimeField(blank=True, null=True)
    
    created = models.DateTimeField(auto_now_add=True)
    outdoor_id = models.IntegerField(default=0)
    
#    objects = CardManager()
    
    class Meta:
        db_table = 'cards'
        
    class Admin:
        search_fields = ['card_key']

        
    def __str__(self):
        if self.owner:
            return "#%s, собственик - %s" % (self.card_key, self.owner.fullname())
        else:
            return "#%s, собственик - не" % (self.card_key,)
            
LOG_TYPE = (
    (0, 'НОРМАЛНО'),
    (1, 'ОТСЪСТВАЩ'),
    (2, 'ОСВОБОДЕН'),
    (3, 'ЗАКЪСНЯЛ'),
    (4, 'НА ВХОДА'),
    (5, 'СИСТЕМА'),
)
            
class LogJournal(models.Model):
    log_date = myfields.DateField(db_index=True)
    card = models.ForeignKey(Card, related_name="events")
    person = models.ForeignKey(uprofile.UserProfile, related_name="activity_events")
    room_id = models.IntegerField(db_index=True, default=0)
    in_event = models.DateTimeField(blank=True, null=True)
    out_event = models.DateTimeField(blank=True, null=True)
    log_type = models.IntegerField(choices=LOG_TYPE, default=0)
        
    class Meta:
        db_table = 'log_events'
        
    class Admin:
        pass
        
