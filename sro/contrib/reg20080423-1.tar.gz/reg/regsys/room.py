# -*- coding: utf-8 -*-
from django.db import models

class Room(models.Model):
    room_number = models.IntegerField(db_index=True)
    title = models.CharField(maxlength=60, default="")
    comment = models.TextField(default="")
    
    class Meta:
        db_table = "rooms"
    
    class Admin:
        pass
        
    def __str__(self):
        return self.title
