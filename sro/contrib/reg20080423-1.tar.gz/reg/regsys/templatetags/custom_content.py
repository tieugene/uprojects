from django import template
from django.shortcuts import render_to_response
from reg.regsys.uprofile import UserProfile

register = template.Library()

@register.inclusion_tag('custom_greeting.html')
def greeting_content(profile=None, pag="_index.html"):
    if profile is None or profile == "":
        t = template.loader.get_template("custom/visitor_index.html")
        return {'user': None, 'content' : t.render({}) }
        
    role = profile.role
    user = profile.user
    
    log = profile.loggedByCard()
    if role in (2,3):
        student_count = UserProfile.objects.logged_student_count(log[3])
        t = template.loader.get_template("custom/teacher_index.html")
        return {'user': profile.user, 'content' : t.render({'log':log, 'student_count':student_count}) } 
        
    elif role == 1:
        t = template.loader.get_template("custom/parent_index.html")
    elif role == 0:
        t = template.loader.get_template("custom/student_index.html")
    elif role in (252, 253):
        t = template.loader.get_template("custom/headmaster_index.html")
    elif role == 254:
        t = template.loader.get_template("custom/admin_index.html")
        
    return {'user': profile.user, 'content' : t.render({'log':log}) } 
