
from django.db.models.fields import Field, DateField as _DateField


class DateField(_DateField):

    def get_db_prep_save(self, value):
        if value is not None:
            if type(value) is not str:
                # Casts dates into string format for entry into database
                value = value.strftime('%Y-%m-%d')
            # else assume value is well formated date string
        return Field.get_db_prep_save(self, value)

