CREATE OR REPLACE FUNCTION card_event(aroom_id int, acard_key char(10)) RETURNS integer AS $$
DECLARE
    card_row RECORD;
BEGIN
    
    SELECT INTO card_row id, owner_id, valid, logged, room_id, log_id, outdoor_id FROM cards WHERE card_key = acard_key 
	FOR UPDATE;
    
    IF NOT FOUND AND aroom_id = 73 THEN
        -- card is unknown - put it into pending card
        DELETE FROM pending_card;
        INSERT INTO pending_card (card_key, read_from_room_id, known, found_id) VALUES (acard_key, aroom_id, 'f', 0);
        RETURN 4;
    END IF;
    
    IF FOUND AND aroom_id = 73 THEN
	DELETE FROM pending_card;
	INSERT INTO pending_card(card_key, read_from_room_id, known, found_id) VALUES (acard_key, aroom_id, 't', card_row.id);
	RETURN 8;
    END IF;
    
    IF FOUND AND (aroom_id = 74 OR aroom_id = 75) THEN
	IF card_row.outdoor_id = 0 THEN
    	    INSERT INTO log_events (log_date, card_id, room_id, in_event, person_id, log_type) VALUES (
        	CURRENT_DATE, card_row.id, 74, NOW(), card_row.owner_id, 4);
	    UPDATE cards SET outdoor_id = (SELECT CURRVAL('log_events_id_seq')) WHERE id = card_row.id;
	    RETURN 9;
	ELSE
    	    UPDATE log_events SET out_event = NOW() WHERE id = card_row.outdoor_id;
	    UPDATE cards SET outdoor_id = 0 WHERE id = card_row.id;
	    IF card_row.logged = 't' THEN
    		-- card is already logged at some room - do logout
    		UPDATE log_events SET out_event = NOW() WHERE id = card_row.log_id;
    		UPDATE cards SET logged = 'f', room_id = 0, log_id = 0, 
            	    event=NOW() 
        	WHERE cards.id = card_row.id;
	    END IF;
	    RETURN 10;
	END IF;
    END IF;
    
    IF card_row.logged = 't' AND card_row.room_id = aroom_id THEN
        -- card is already logged at same room - do logout
        UPDATE log_events SET out_event = NOW() WHERE id = card_row.log_id;
        UPDATE cards SET logged = 'f', room_id = 0, log_id = 0, 
                event=NOW() 
            WHERE id = card_row.id;
	RETURN 1;
    END IF;
        
    IF card_row.logged = 't' AND card_row.room_id <> aroom_id THEN
        -- card is already logged at different room - do logout and then login here
        UPDATE log_events SET out_event = NOW() WHERE id = card_row.log_id;
        INSERT INTO log_events (log_date, card_id, room_id, in_event, person_id) VALUES (
            CURRENT_DATE, card_row.id, aroom_id, NOW(), card_row.owner_id);
        UPDATE cards SET logged = 't', room_id = aroom_id, log_id = (SELECT CURRVAL('log_events_id_seq')),
                event=NOW()
            WHERE id = card_row.id;
	RETURN 2;
    END IF;
    
    IF card_row.logged = 'f' THEN
        -- card is not logged - login
        INSERT INTO log_events (log_date, card_id, room_id, in_event, person_id) VALUES (
            CURRENT_DATE, card_row.id, aroom_id, NOW(), card_row.owner_id);
        UPDATE cards SET logged = 't', room_id = aroom_id, log_id = (SELECT CURRVAL('log_events_id_seq')),
                event=NOW()
            WHERE id = card_row.id;
	RETURN 3;        
    END IF;
    
    RETURN 5;
END
$$ LANGUAGE 'plpgsql';
