CREATE OR REPLACE FUNCTION force_logout(aroom_id int) RETURNS integer AS $$
DECLARE
card_row RECORD;
log_id_c int;
outdoor_id_c int;
BEGIN
    LOCK TABLE log_events IN SHARE ROW EXCLUSIVE MODE;
    FOR card_row IN SELECT * FROM cards WHERE logged = 't' FOR UPDATE OF cards LOOP
        log_id_c = card_row.log_id;
	outdoor_id_c = card_row.outdoor_id;
	
        UPDATE cards SET logged = 'f', room_id = 0, log_id = 0, outdoor_id = 0 WHERE id = card_row.id;
        IF log_id_c > 0 THEN
            UPDATE log_events SET out_event = NOW(), log_type = 5 WHERE id = log_id_c;
        END IF;
	IF outdoor_id_c > 0 THEN
	    UPDATE log_events SET out_event = NOW(), log_type = 5 WHERE id = outdoor_id_c;
	END IF;
    END LOOP;
    RETURN 1;
 END
$$ LANGUAGE 'plpgsql';
