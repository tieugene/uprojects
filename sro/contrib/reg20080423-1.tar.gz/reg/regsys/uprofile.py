# -*- coding: utf-8 -*-
from django.db import models, connection
from django.contrib.auth.models import User
from time import strftime

USER_ROLES = (
    (0,     'УЧЕНИК'),
    (1,     'РОДИТЕЛ'),
    (2,     'УЧИТЕЛ'),
    (3,     'КЛАСЕН Р-ТЕЛ'),
    (252, 'ДИРЕКТОР'),
    (253, 'ИНСПЕКТОР'),
    (254, 'СУПЕРВАЙЗОР'),
)

USER_ROLES2 = (
    (-1,    'ВСИЧКИ'),
    (0,     'УЧЕНИК'),
    (1,     'РОДИТЕЛ'),
    (2,     'УЧИТЕЛ'),
    (3,     'КЛАСЕН Р-ТЕЛ'),
    (4,     'ПОМОЩЕН ПЕРСОНАЛ'),
    (252, 'ДИРЕКТОР'),
    (253, 'ИНСПЕКТОР'),
    (254, 'СУПЕРВАЙЗОР'),
)

class ProfileManager(models.Manager):
    def logged_by_card(self, user):
        c = connection.cursor()
        c.execute("""
                    SELECT c.logged, r.title, DATE(c.event), c.room_id
                    FROM cards AS c, rooms AS r WHERE
                        c.owner_id = %s AND c.logged = True AND
                        r.room_number = c.room_id
            """, (user.id,))
        log = c.fetchone()
        if log is None:
            return (False, "", "", 0)
        else:
            return log
            
    def logged_student_count(self, room_id):
        c = connection.cursor()
        c.execute("""
                    SELECT COUNT(*)
                    FROM cards AS c, regsys_userprofile as u WHERE
                        c.owner_id = u.id AND u.role = 0 AND 
                        c.logged = True AND DATE(c.event) = DATE(NOW()) AND
                        c.room_id = %s
            """, (room_id,))
        return c.fetchone()[0]
        
    def student_list_in_room(self, room_id, grade):
        c = connection.cursor()
        c.execute("""SELECT u.reg_n, u.first_name, u.second_name, u.last_name, u.id 
                    FROM cards AS c, regsys_userprofile as u WHERE
                        c.owner_id = u.id AND u.role = 0 AND u.grade = %s AND
                        c.logged = True AND DATE(c.event) = DATE(NOW()) AND
                        c.room_id = %s 
                    ORDER BY 1 ASC, 2 ASC, 3 ASC, 4 ASC
            """, (grade, room_id,))
        return c.fetchall()

    def student_list_away_room(self, room_id, grade):
        c = connection.cursor()
        c.execute("""SELECT u.reg_n, u.first_name, u.second_name, u.last_name, u.id 
                    FROM regsys_userprofile as u, cards AS c WHERE
                        c.owner_id = u.id AND u.role = 0 AND u.grade = %s AND
                        (c.logged = False OR (c.logged=True AND c.room_id <> %s))
                    ORDER BY 1 ASC, 2 ASC, 3 ASC, 4 ASC
            """, (grade, room_id))
        return c.fetchall()
        
    def student_list_all(self, grade, room_id = 0):
        c = connection.cursor()
        c.execute("""SELECT u.reg_n, u.first_name, u.second_name, u.last_name, u.id, 
                        c.logged, c.room_id, (SELECT title FROM rooms WHERE room_number = c.room_id)
                    FROM regsys_userprofile as u, cards AS c WHERE
                        c.owner_id = u.id AND u.role = 0 AND u.grade = %s
                    ORDER BY 1 ASC, 2 ASC, 3 ASC, 4 ASC
            """, (grade,))
        recs = c.fetchall()
        students = []
        for r in recs:
            c.execute("""SELECT log_type FROM log_events WHERE person_id = %s ORDER BY id DESC LIMIT 1""", (r[4],))
            try:
                (log_type,) = c.fetchone()
            except:
                log_type = 0
                
            if log_type == 0:
                status = 'НОРМАЛНО'
            elif log_type == 1:
                status = 'ОТСЪСТВА'
            elif log_type == 2:
                status = 'ОСВОБОДЕН'
            elif log_type == 3:
                status = 'ЗАКЪСНЯЛ'
            elif log_type == 4:
                status = 'НА ВХОДА'
            elif log_type == 5:
                status = 'СИСТЕМА'
            if log_type > 0:
                warn = 1
            else:
                warn = 0
            students.append((r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], status, warn))
        return students
        
    def log_journal(self,  profile_id,  beg_date,  beg_hour,  end_date,  end_hour):
        c = connection.cursor()
        c.execute("""SELECT log.log_date, r.room_number, r.title, r.id, log.in_event, log.out_event,
                                CASE WHEN log.log_type = 0 THEN 'НОРМАЛНО'
                                          WHEN log.log_type = 1 THEN 'ОТСЪСТВА'
                                          WHEN log.log_type = 2 THEN 'ОСВОБОДЕН'
                                          WHEN log.log_type = 3 THEN 'ЗАКЪСНЯЛ'
                                          WHEN log.log_type = 1 THEN 'НА ВХОДА'
                                          WHEN log.log_type = 1 THEN 'СИСТЕМА'
                                END
                                FROM log_events AS log, rooms AS r WHERE
                                log.room_id = r.room_number AND
                                log.person_id =%s AND log.log_date BETWEEN %s AND %s AND
                                log.in_event >= %s AND (log.out_event <= %s OR log.out_event IS Null)
                            ORDER BY 1
                """,  (profile_id,  beg_date,  end_date,  beg_date + ' ' + beg_hour,  end_date + ' ' + end_hour))
        return c.fetchall()
        
    def where_are_teachers(self, adate, ahour):
        c = connection.cursor()
        c.execute("""SELECT first_name || ' ' || second_name || ' ' || last_name, role, grade, id 
                    FROM regsys_userprofile WHERE role IN (2, 3, 252, 253) ORDER BY 1""")
        teachers = c.fetchall()
        res = []
        for t in teachers:
            c.execute("""SELECT log.log_date, r.room_number, r.title, r.id, log.in_event, log.out_event
                                FROM log_events AS log, rooms AS r WHERE
                                log.room_id = r.room_number AND
                                log.person_id =%s AND log.log_type IN (0,5) AND log_date=%s AND
                                log.in_event <= %s AND (log.out_event <= %s OR log.out_event IS Null)
                            ORDER BY log.id DESC LIMIT 1
                """,  (t[3],  adate,  adate + ' ' + ahour, adate + ' ' + ahour))
            normal_log = c.fetchone()
            if normal_log is None:
                room = '-'
                room_id = 0
                in_event = ''
                out_event = ''
            else:
                room = '#' + str(normal_log[1]) + ' - ' + normal_log[2]
                room_id = normal_log[3]
                in_event = normal_log[4]
                out_event = normal_log[5]

            c.execute("""SELECT log.in_event, log.out_event
                                FROM log_events AS log, rooms AS r WHERE
                                log.room_id = r.room_number AND
                                log.person_id =%s AND log.log_type = 4 AND log_date=%s AND
                                log.in_event <= %s AND (log.out_event <= %s OR log.out_event IS Null)
                            ORDER BY log.id DESC LIMIT 1
                """,  (t[3],  adate,  adate + ' ' + ahour, adate + ' ' + ahour))
            door_log = c.fetchone()
            if door_log is None:
                door_in = ''
                door_out = ''
            else:
                door_in = door_log[0]
                door_out = door_log[1]

            role_str = '-'
            res.append((t[0], role_str, door_in, door_out, room, room_id, in_event, out_event, t[3]))
            
        return res
        
class UserProfile(models.Model):
    """
        The system will not use the User model for any specific user data,
        so, here is extended model for user data
    """
    user = models.ForeignKey(User, unique=True)
    #
    role = models.IntegerField(choices=USER_ROLES, default=1, db_index=True)
    title = models.CharField(maxlength=10, null=True, blank=True)
    
    # User model does not provide 'second_name' field. 
    first_name = models.CharField(maxlength=30, default="")
    second_name = models.CharField(maxlength=30, default="")
    last_name = models.CharField(maxlength=30, default="")
    
    grade = models.CharField(maxlength=10, default="", db_index=True)
    reg_n = models.IntegerField(default=0)
    picture = models.ImageField(upload_to='photos/%Y/%m/%d', blank=True, null=True)
    #
    job = models.CharField(maxlength=30, default="")
    #
    created = models.DateTimeField(auto_now_add=True)
    
    objects = ProfileManager()
        
    class Meta:
        db_table = 'regsys_userprofile'
        unique_together = (("first_name", "second_name", "last_name", "grade", "reg_n"), ) 
        ordering = ('grade', 'reg_n') 
        
    class Admin:
        pass
        
    def is_teacher(self):
        if self.role in (2, 3, 252, 253, 254):
           return True
        else:
            return False
        
    def save(self):
        self.role = int(self.role)
        if self.role not in (0, 3):
            self.grade = ''
            self.reg_n = 0
        super(UserProfile, self).save()
        
    def fullname(self):
        if self.role !=0:
            return "%s %s %s" % (self.title, self.first_name, self.last_name)
        else:
            return "%s %s %s - ученик във %s клас" % (self.first_name, self.second_name, self.last_name, self.grade)
            
    def __str__(self):
        return self.fullname()
        
    def just_name(self):
        return "%s %s %s" % (self.first_name, self.second_name, self.last_name)
        
            
    def loggedByCard(self):
        log = UserProfile.objects.logged_by_card(self)
        if log[0] and str(log[2]) < strftime("%Y-%m-d%"):
            # user is logged, but log event is not from today - 
            # automatic user log out by card
            # TODO:
            pass
        return log
    
            
    def get_menu(self):
        if self.role == 2:
            # teacher
            return (
                ("/grade/list", "Списък на класа"),
                ("/room/student/present_list", "Присъстващи"),
                ("/room/student/away_list", "Отсъстващи"),
            )
        elif self.role == 3:
            # master
            return (
                ("/grade/list", "Списък на класа"),
                ("/room/student/present_list", "Присъстващи"),
                ("/room/student/away_list", "Отсъстващи"),
                ("-", ""),
                ("/my_students", "Списък на моя клас"),
            )

        elif self.role in  (252, 253):
            return (
                ("/grade/list", "Списък на класа"),
                ("/room/student/present_list", "Присъстващи"),
                ("/room/student/away_list", "Отсъстващи"),
                ("-", ""),

                ("/card/list", "Списък по карти"),
                ("/teachers/status", "Къде са учителите"),
                ("/room/list", "Стаи"),
            )
            
        elif self.role == 254:
            # admin
            return (
                ("/card/wait_new", "Регистрация на карта"),
                ("/card/list", "Списък на картите"),
                ("-", ""),
                ("/room/new", "Нов четец"),
                ("/room/list", "Списък на четците"),
            )
    
