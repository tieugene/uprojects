# -*- coding: utf-8 -*-
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from django import template

def index(request):
    return render_to_response('index.html', context_instance=template.RequestContext(request))
    
def error(request):
    return render_to_response('error.html', context_instance=template.RequestContext(request))
    
def my_logout(request):
    logout(request)
    return HttpResponseRedirect("/")
    
def my_login(request):
    if request.POST:
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect("/")
            else:
                return HttpResponseRedirect("/")
    else:
        user = None
    context_instance = template.RequestContext(request, {'login_error':"Грешка при влизането"})
    return render_to_response('index.html', context_instance)

    
