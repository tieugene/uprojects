# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from django import template
from django import newforms as forms
from django.contrib.auth.models import User
from django.db import transaction
from reg.regsys.cards import Card, PendingRegistrationCard
from reg.regsys.uprofile import UserProfile, USER_ROLES
from reg.regsys.room import Room
from PIL import Image
from StringIO import StringIO
from reg import settings
from decorators import require_role

class CardForm(forms.Form):
    title = forms.CharField(widget=forms.TextInput(attrs={'size':10}), label = "Титла", max_length=10, required=False)
    first_name = forms.CharField(widget=forms.TextInput(attrs={'size':50}), label = "Име", max_length=30, required=True)
    second_name = forms.CharField(widget=forms.TextInput(attrs={'size':50}), label = "Презиме", max_length=30, required=True)
    last_name = forms.CharField(widget=forms.TextInput(attrs={'size':50}), label = "Фамилия", max_length=30, required=True)
    #
    role = forms.ChoiceField(choices=USER_ROLES, label="Роля", required=True)
    grade = forms.CharField(widget=forms.TextInput(attrs={'size':5}), label = "Клас", max_length=3, required=False)
    reg_n = forms.CharField(widget=forms.TextInput(attrs={'size':5}), label = "Номер", max_length=2, required=False)
    job = forms.CharField(widget=forms.TextInput(attrs={'size':32}), label = "Професия", max_length=30, required=False)
    picture = forms.Field(widget=forms.FileInput, required=False, label="Снимка")
    #
    uname = forms.CharField(widget=forms.TextInput(attrs={'size':32}), label = "Потребител", max_length=30, required=False)
    upwd = forms.CharField(widget=forms.PasswordInput(attrs={'size':20}), label = "Парола", max_length=20, required=False)

    def clean_grade(self):
        _grade = self.clean_data.get('grade')
        if self.clean_data.get('role') in ('0', '3'):
            if _grade == u"" or _grade is None:
                raise forms.ValidationError(u"Задайте клас")
                
            if self.clean_data.get('role') == '3':
                if UserProfile.objects.filter(grade__exact=_grade.upper().encode("utf-8"), 
                        role__exact=3).count() > 0:
                    raise forms.ValidationError(u"Вече има регистр. класен р-тел за този клас")
                
            return _grade
        else:
            return u""
    
    def clean_reg_n(self):
        _grade = self.clean_data.get('grade')
        _rn = self.clean_data.get('reg_n')
        if self.clean_data.get('role') == '0':
            if _rn == "" or _rn is None:
                raise forms.ValidationError(u"Задайте номер")
                
            try:
                a = int(_rn)
            except:
                raise forms.ValidationError(u"Номера не е число")

            if UserProfile.objects.filter(grade__exact=_grade.upper().encode("utf-8"), 
                        reg_n__exact=a, role__exact=0).count() > 0:
                raise forms.ValidationError(u"Вече има регистр. ученик с този номер")
            return int(_rn)
        else:
            return 0
            

    def clean_picture(self):
        if self.clean_data.get('picture'):
            photo_data = self.clean_data['picture']
            if 'error' in photo_data:
                raise forms.ValidationError("Изображението е развалено или не е снимка")
            content_type = photo_data.get('content-type')
            if content_type:
                main, sub = content_type.split('/')
                if not (main=='image' and sub in ('jpeg', 'jpg', 'gif', 'png')):
                    raise forms.ValidationError("Формата не е jpeg, gif или png")
                
                size = len(photo_data['content'])
                if size > settings.MAX_PHOTO_UPLOAD_SIZE * 1024:
                    raise forms.ValidationError("Изображението е твърде голямо")
                    
                width, height = photo_data['dimensions']
                if width > settings.MAX_PHOTO_WIDTH:
                    raise forms.ValidationError("Макс. ширина = %s" % (settings.MAX_PHOTO_WIDTH,))
                if height > settings.MAX_PHOTO_HEIGHT:
                    raise forms.ValidationError("Макс. височина = %s" % (settings.MAX_PHOTO_HEIGHT,))
                    
        return self.clean_data['picture']

    def clean_uname(self):
        if int(self.clean_data.get('role')) >= 1:
            if self.clean_data.get('uname') == "" or self.clean_data.get('uname') is None:
                raise forms.ValidationError('Задайте потребителско име')
        return self.clean_data.get('uname')
        
    def clean_upwd(self):
        if int(self.clean_data.get('role')) >= 1:
            if self.clean_data.get('upwd') == "" or self.clean_data.get('upwd') is None:
                raise forms.ValidationError('Задайте парола за влизане')
        return self.clean_data.get('upwd')
        
@require_role(252, "/error/")
@transaction.commit_manually
def new_card(request):
    pending = PendingRegistrationCard.objects.getPendingCard()
    if request.method == 'POST':
        if 'picture' in request.FILES:
            try:
                img = Image.open(StringIO(request.FILES['picture']['content']))
                request.FILES['picture']['dimensions'] = img.size
            except:
                request.FILES['picture']['error'] = True
                
        post_data = request.POST.copy()
        post_data.update(request.FILES)
        form = CardForm(post_data)
    else:
        form = CardForm()

    msg = ""
    if form.is_valid():
        import md5, time, random
        # 1. create system user
        # 1.1 if username or password are empty - generate them
        uname = form.clean_data['uname'].encode('utf-8')
        if pending[0]:
            ck = pending[1].card_key
        else:
            ck = 'anonuser'
        if uname is None or uname == '':            
            uname = md5.md5(ck + str(time.time())  + str(random.random())).hexdigest()
        upwd = form.clean_data['upwd'].encode('utf-8')
        if upwd is None or upwd == '':
            uname = md5.md5(ck + str(time.time()) + 'xx502dfw1' + str(random.random())).hexdigest()[:8]
        success = True
        u = User.objects.create_user(username=uname, email="", password=upwd)
        try:
            u.save()
        except:
            success = False
            msg = "Грешка при създаване на потребител"
            
        # 2. create user profile
        if success:
            if form.clean_data['picture']:
                pic = form.clean_data['picture']
            else:
                pic = None
            profile = UserProfile(
                user = u,
                role = int(form.clean_data['role']),
                title=form.clean_data['title'].upper().encode("utf-8"),
                first_name=form.clean_data['first_name'].upper().encode("utf-8"),
                second_name=form.clean_data['second_name'].upper().encode("utf-8"),
                last_name=form.clean_data['last_name'].upper().encode("utf-8"),
                grade = form.clean_data['grade'].upper().encode("utf-8"),
                reg_n = int(form.clean_data['reg_n'])
                )
            try:
                profile.save()
                if pic is not None:
                    profile.save_picture_file(pic['filename'], pic['content'])
            except:
                success = False
                msg = "Грешка при записа на потреб. профил"
                                
        # 3. create and assign card
        if success:
            if Card.objects.filter(card_key__exact=pending[1].card_key).count() > 0:
                msg = "Грешка при записа на картата - картата вече е регистрирана"
                success = False
                print "card exists"
            else:
                card = Card(card_key = pending[1].card_key, owner=profile)
                try:
                    card.save()
                except:
                    msg = "Грешка при записа на картата"
                    success = False
    
        if success:
            PendingRegistrationCard.objects.deletePending()
            request.user.message_set.create(message="Регистрацията на нова карта е успешна.")
            transaction.commit()
            return HttpResponseRedirect("/")
        else:
            transaction.rollback()

    if msg != "":
        request.user.message_set.create(message=msg)
        
    context_instance=template.RequestContext(request, {'form':form, 'pending':pending})
    transaction.commit()
    return render_to_response('forms/new_card.html', context_instance)
    
class ProfileEditForm(forms.Form):
    title = forms.CharField(widget=forms.TextInput(attrs={'size':10}), label = "Титла", max_length=10, required=False)
    first_name = forms.CharField(widget=forms.TextInput(attrs={'size':50}), label = "Име", max_length=30, required=True)
    second_name = forms.CharField(widget=forms.TextInput(attrs={'size':50}), label = "Презиме", max_length=30, required=True)
    last_name = forms.CharField(widget=forms.TextInput(attrs={'size':50}), label = "Фамилия", max_length=30, required=True)
    #
    role = forms.ChoiceField(choices=USER_ROLES, label="Роля", required=True)
    grade = forms.CharField(widget=forms.TextInput(attrs={'size':5}), label = "Клас", max_length=3, required=False)
    reg_n = forms.CharField(widget=forms.TextInput(attrs={'size':5}), label = "Номер", max_length=2, required=False)
    job = forms.CharField(widget=forms.TextInput(attrs={'size':32}), label = "Професия", max_length=30, required=False)
    picture = forms.Field(widget=forms.FileInput, required=False, label="Снимка")
    #
    uname = forms.CharField(widget=forms.TextInput(attrs={'size':32}), label = "Потребител", max_length=30, required=False)
    upwd = forms.CharField(widget=forms.PasswordInput(attrs={'size':20}), label = "Парола", max_length=100, required=False)
    
    def clean_grade(self):
        _grade = self.clean_data.get('grade')
        if self.clean_data.get('role') in ('0', '3'):
            if _grade == u"" or _grade is None:
                raise forms.ValidationError(u"Задайте клас")
                
            if self.clean_data.get('role') == '3':
                if UserProfile.objects.filter(grade__exact=_grade.upper().encode("utf-8"), 
                        role__exact=3).count() > 1:
                    raise forms.ValidationError(u"Вече има регистр. класен р-тел за този клас")
                
            return _grade
        else:
            return u""
    
    def clean_reg_n(self):
        _grade = self.clean_data.get('grade')
        _rn = self.clean_data.get('reg_n')
        if self.clean_data.get('role') == '0':
            if _rn == "" or _rn is None:
                raise forms.ValidationError(u"Задайте номер")
                
            try:
                a = int(_rn)
            except:
                raise forms.ValidationError(u"Номера не е число")

            if UserProfile.objects.filter(grade__exact=_grade.upper().encode("utf-8"), 
                        reg_n__exact=a, role__exact=0).count() > 1:
                raise forms.ValidationError(u"Вече има регистр. ученик с този номер")
            return int(_rn)
        else:
            return 0
            
    def clean_picture(self):
        if self.clean_data.get('picture'):
            photo_data = self.clean_data['picture']
            if 'error' in photo_data:
                raise forms.ValidationError("-eИзображението е развалено или не е снимка")
            content_type = photo_data.get('content-type')
            if content_type:
                main, sub = content_type.split('/')
                if not (main=='image' and sub in ('jpeg', 'jpg', 'gif', 'png')):
                    raise forms.ValidationError("Формата не е jpeg, gif или png")
                
                size = len(photo_data['content'])
                if size > settings.MAX_PHOTO_UPLOAD_SIZE * 1024:
                    raise forms.ValidationError("Изображението е твърде голямо")
                    
                width, height = photo_data['dimensions']
                if width > settings.MAX_PHOTO_WIDTH:
                    raise forms.ValidationError("Макс. ширина = %s" % (settings.MAX_PHOTO_WIDTH,))
                if height > settings.MAX_PHOTO_HEIGHT:
                    raise forms.ValidationError("Макс. височина = %s" % (settings.MAX_PHOTO_HEIGHT,))
                    
        return self.clean_data['picture']

    def clean_uname(self):
        if int(self.clean_data.get('role')) >= 1:
            if self.clean_data.get('uname') == "" or self.clean_data.get('uname') is None:
                raise forms.ValidationError('Задайте потребителско име')
        return self.clean_data.get('uname')
        
    def clean_upwd(self):
        if int(self.clean_data.get('role')) >= 1:
            if self.clean_data.get('upwd') == "" or self.clean_data.get('upwd') is None:
                raise forms.ValidationError('Задайте парола за влизане')
        return self.clean_data.get('upwd')

@require_role(252, "/error/")
@transaction.commit_manually
def edit_profile(request, profile_id):
    profile = UserProfile.objects.get(pk=profile_id)
    if request.method == 'POST':
        if 'picture' in request.FILES:
            try:
                img = Image.open(StringIO(request.FILES['picture']['content']))
                request.FILES['picture']['dimensions'] = img.size
            except:
                request.FILES['picture']['error'] = True
                
        post_data = request.POST.copy()
        post_data.update(request.FILES)
        form = ProfileEditForm(post_data)
        if form.is_valid():
            msg = ""
            success = True
            
            if form.clean_data['picture']:
                pic = form.clean_data['picture']
            else:
                pic = None
                
            u = profile.user
            uname = form.clean_data['uname'].encode('utf-8')
            if uname is None or uname == '':
                uname = md5.md5('anonuser' + str(time.time())  + str(random.random())).hexdigest()
                
            u.username = uname
            if form.clean_data['upwd'] != u.password:
                u.set_password(form.clean_data['upwd'])
            
            profile.role = int(form.clean_data['role'])
            profile.title=form.clean_data['title'].upper().encode("utf-8")
            profile.first_name=form.clean_data['first_name'].upper().encode("utf-8")
            profile.second_name=form.clean_data['second_name'].upper().encode("utf-8")
            profile.last_name=form.clean_data['last_name'].upper().encode("utf-8")
            profile.grade = form.clean_data['grade'].upper().encode("utf-8")
            profile.reg_n = int(form.clean_data['reg_n'])
            try:
                u.save()
                profile.save()
                if pic is not None:
                    profile.save_picture_file(pic['filename'], pic['content'])
            except:
                success = False
                msg = "Грешка при записа на потреб. профил"
                
            if success:
                try:
                    u = int(request.GET.get('u'))
                except:
                    u = 0
                request.user.message_set.create(message="Промяната на профила е успешна.")
                transaction.commit()
                return HttpResponseRedirect("/profile/" + str(profile.id) + "/?u=" + str(u))
            else:
                transaction.rollback()
                if msg != "":
                    request.user.message_set.create(message=msg)
                            
    else:
        form = ProfileEditForm(initial={
                'title':profile.title,
                'first_name':profile.first_name,
                'second_name':profile.second_name,
                'last_name':profile.last_name,
                'role':profile.role,
                'grade':profile.grade,
                'reg_n':profile.reg_n,
                'job':profile.job,
                'picture':profile.picture,
                'uname':profile.user.username,
                'upwd':profile.user.password,
            })
    transaction.commit()
    context_instance=template.RequestContext(request, {'form':form, 'old_pic':profile.picture})
    return render_to_response('forms/edit_profile.html', context_instance)
    
class RoomForm(forms.Form):
    room_number = forms.CharField(widget=forms.TextInput(attrs={'size':4}), label = "Номер", max_length=3, required=True)
    title = forms.CharField(widget=forms.TextInput(attrs={'size':64}), label = "Име", max_length=30, required=True)
    comment = forms.CharField(widget=forms.Textarea(), max_length=100, required=False)

    def clean_room_number(self):
        rn = self.clean_data.get('room_number')
        if rn is None or rn == "":
            raise forms.ValidationError("Задайте номер")
        try:
            rnn = int(rn)
        except:
            raise forms.ValidationError("Номера не е число")
            
        if Room.objects.filter(room_number__exact=rnn).count() > 0:
            raise forms.ValidationError("Вече има карточетец с този номер")
            
        return int(rn)
        
    def clean_title(self):
        t = self.clean_data.get('title')
        if t is None or t == "":
            raise forms.ValidationError("Задайте наименование")
            
        return t

@require_role(252, "/error/")
@transaction.commit_manually
def new_room(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = RoomForm(post_data)
    else:
        form = RoomForm()
        
    msg = ""
    if form.is_valid():
        success = True
        room = Room(
            room_number = int(form.clean_data['room_number']),
            title = form.clean_data['title'].upper().encode('utf-8'),
            comment = form.clean_data['comment'].upper().encode('utf-8')
            )
        try:
            room.save()
        except:
            msg = "Грешка при създаване на карточетеца"
            success = False
            
        if success:
            request.user.message_set.create(message="Регистрацията на нов четец е успешна.")
            transaction.commit()
            return HttpResponseRedirect("/")
        else:
            transaction.rollback()

    if msg != "":
        request.user.message_set.create(message=msg)

    context_instance=template.RequestContext(request, {'form':form})
    return render_to_response('forms/new_room.html', context_instance)
    
