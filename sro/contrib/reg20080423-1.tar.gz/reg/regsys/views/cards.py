# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django import template
from reg.regsys.cards import Card, PendingRegistrationCard
from django.db import transaction
from django import newforms as forms
from reg.regsys.uprofile import USER_ROLES2
from django.core.paginator import ObjectPaginator, InvalidPage
from decorators import require_role

class CardFilterForm(forms.Form):
    first_name = forms.CharField(widget=forms.TextInput(attrs={'size':25}), label = "Име", max_length=30, required=False)
    second_name = forms.CharField(widget=forms.TextInput(attrs={'size':25}), label = "Презиме", max_length=30, required=False)
    last_name = forms.CharField(widget=forms.TextInput(attrs={'size':25}), label = "Фамилия", max_length=30, required=False)
    #
    role = forms.ChoiceField(choices=USER_ROLES2, label="Роля", required=False)
    grade = forms.CharField(widget=forms.TextInput(attrs={'size':5}), label = "Клас", max_length=3, required=False)
    reg_n = forms.CharField(widget=forms.TextInput(attrs={'size':5}), label = "Номер", max_length=2, required=False)
    
    def clean_reg_n(self):
        print "clearing reg_n"
        _rn = self.clean_data.get('reg_n')
        try:
            a = int(_rn)
        except:
            a = 0
        return a
        
@require_role(252, "/error/")
def show_card_list(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = CardFilterForm(post_data)
        
        if form.is_valid():

            first_name = form.clean_data['first_name'].upper().encode('utf-8')
            second_name = form.clean_data['second_name'].upper().encode('utf-8')
            last_name = form.clean_data['last_name'].upper().encode('utf-8')
            role = int(form.clean_data['role'])
            grade = form.clean_data['grade'].upper().encode('utf-8')
            reg_n = form.clean_data['reg_n']

            cards = Card.objects.all()
            
            if first_name != "":
                cards = cards.filter(owner__first_name__exact = first_name)
                
            if second_name != "":
                cards = cards.filter(owner__second_name__exact = second_name)

            if last_name != "":
                cards = cards.filter(owner__last_name__exact = last_name)
                
            if role != -1:
                cards = cards.filter(owner__role__exact = role)
                
            if grade != "":
                cards = cards.filter(owner__grade__exact = grade)
                
            if reg_n != 0:
                cards = cards.filter(owner__reg_n__exact = reg_n)

            cards = cards.select_related().order_by('regsys_userprofile.first_name', 'regsys_userprofile.second_name', 'regsys_userprofile.last_name', 'regsys_userprofile.reg_n')
        else:
            cards = Card.objects.all()
            cards = cards.select_related().order_by('regsys_userprofile.first_name', 'regsys_userprofile.second_name', 'regsys_userprofile.last_name', 'regsys_userprofile.reg_n')
    else:
        cards = Card.objects.all()
        cards = cards.select_related().order_by('regsys_userprofile.first_name', 'regsys_userprofile.second_name', 'regsys_userprofile.last_name', 'regsys_userprofile.reg_n')
        form = CardFilterForm()
    
    paginator = ObjectPaginator(cards, 30)
    try:
        page = int(request.GET.get('page'))
    except:
        page = 1
        
    try:
        cards = paginator.get_page(page-1)
    except InvalidPage: 
        raise Http404
            
    context_instance = template.RequestContext(request, 
        {
        'form':form, 
        'card_list':cards,
        'paginator':paginator,
        'is_paginated': paginator.pages > 1,
        'has_next': paginator.has_next_page(page - 1),
        'has_previous': paginator.has_previous_page(page - 1),
        'current_page': page,
        'next_page': page + 1,
        'previous_page': page - 1,
        'pages': range(paginator.pages),
        'hits' : paginator.hits,
        })
    return render_to_response('reports/cards_list.html', context_instance)

@require_role(252, "/error/")    
def detail(request, card_id):
    card = Card.objects.get(pk=card_id)
    context_instance=template.RequestContext(request, {'card':card})
    return render_to_response('view_card.html', context_instance)
    
@require_role(252, "/error/")
def cancel_card(request, card_id):
    card = Card.objects.get(pk=card_id)
    card.valid = False
    card.save()
    return show_card_list(request)
    
@require_role(252, "/error/")
@transaction.commit_manually
def wait_new(request):
    PendingRegistrationCard.objects.deletePending()
    transaction.commit()
    context_instance=template.RequestContext(request)
    return render_to_response('card_wait.html', context_instance)
    
@require_role(252, "/error/")
@transaction.commit_manually
def wait_replace(request, card_id):
    PendingRegistrationCard.objects.deletePending()
    transaction.commit()
    context_instance=template.RequestContext(request, {'replace':True})
    return render_to_response('card_wait.html', context_instance)

@require_role(252, "/error/")
@transaction.commit_manually
def replace_card(request, card_id):
    pending = PendingRegistrationCard.objects.getPendingCard()
    if pending[0]:
        success = True
        msg = ""
        old_card = Card.objects.get(pk=card_id)
        old_card.valid = False
        old_card.save()
        new_card = Card(card_key = pending[1].card_key, owner=old_card.owner)
        try:
            new_card.save()
        except:
            msg = "Грешка при подмяната на картата"
            success = False
        if success:
            PendingRegistrationCard.deletePending()
            request.user.message_set.create(message="Подмяната е успешна!")
            transaction.commit()
            return show_card_list(request)
        else:
            transaction.rollback()
            PendingRegistrationCard.deletePending()
            request.user.message_set.create(message=msg)
            transaction.commit()
            return wait_replace(request, card_id)
    else:
        transaction.commit()
        return wait_replace(request, card_id)
        
