# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from django import template
from reg.regsys.room import Room
from reg.regsys.cards import LogJournal
from django import newforms as forms
from django.core.paginator import ObjectPaginator, InvalidPage
import datetime
from decorators import require_role

@require_role(252, "/error/")
def detail(request, room_id):
    try:
        u = int(request.GET.get('u'))
    except:
        u = 0
    room = Room.objects.get(pk=room_id)
    context_instance=template.RequestContext(request, {'room':room, 'u':u})
    return render_to_response('view_room.html', context_instance)
    
class DatesFilterForm(forms.Form):
    beg_date = forms.CharField(widget=forms.TextInput(attrs={'size':10,  'class':'vDateField'}), label = "Нач.дата", max_length=10, required=True)
    beg_hour = forms.CharField(widget=forms.TextInput(attrs={'size':8,  'class':'vTimeField'}), label = "Нач.час", max_length=8, required=True)
    end_date = forms.CharField(widget=forms.TextInput(attrs={'size':10,  'class':'vDateField'}), label = "Кр.дата", max_length=10, required=True)
    end_hour = forms.CharField(widget=forms.TextInput(attrs={'size':8,  'class':'vTimeField'}), label = "Нач.час", max_length=8, required=True)

    def clean_beg_date(self):
        return self.clean_data['beg_date']
        
    def clean_beg_hour(self):
        return self.clean_data['beg_hour']
        
    def clean_end_date(self):
        return self.clean_data['end_date']
        
    def clean_end_hour(self):
        return self.clean_data['end_hour']

@require_role(252, "/error/")
def show_room_journal(request,  room_id):
    room = Room.objects.get(pk=room_id)
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = DatesFilterForm(post_data)
        
        if form.is_valid():
            beg_date = form.clean_data['beg_date'].upper().encode('utf-8')
            beg_hour = form.clean_data['beg_hour'].upper().encode('utf-8')
            end_date = form.clean_data['end_date'].upper().encode('utf-8')
            end_hour = form.clean_data['end_hour'].upper().encode('utf-8')
            log = LogJournal.objects.filter(room_id__exact=room.room_number).filter(log_date__range=(beg_date,  end_date))
            log = log.filter(in_event__gte=beg_date + ' ' + beg_hour).filter(in_event__lte=end_date + ' ' + end_hour)
        else:
            log = []
                
    else:
        beg_date = str(datetime.datetime.today())[:10]
        beg_hour = '07:30:00'
        end_date = beg_date
        end_hour = '17:30:00'
        log = LogJournal.objects.filter(room_id__exact=room.room_number).filter(log_date__range=(beg_date,  end_date))
        log = log.filter(in_event__gte=beg_date + ' ' + beg_hour).filter(in_event__lte=end_date + ' ' + end_hour)
        form = DatesFilterForm({'beg_date':beg_date, 'beg_hour':beg_hour, 'end_date':end_date,  'end_hour':end_hour})
        
    paginator = ObjectPaginator(log, 30)
    try:
        page = int(request.GET.get('page'))
    except:
        page = 1
        
    try:
        log_list = paginator.get_page(page-1)
    except InvalidPage: 
        raise http.Http404
            
    context_instance = template.RequestContext(request, 
        {
        'form':form, 
        'log_list':log_list,
        'paginator':paginator,
        'is_paginated': paginator.pages > 1,
        'has_next': paginator.has_next_page(page - 1),
        'has_previous': paginator.has_previous_page(page - 1),
        'current_page': page,
        'next_page': page + 1,
        'previous_page': page - 1,
        'pages': range(paginator.pages),
        'hits' : paginator.hits,
        'room_title':room.title, 
        'r_id':room.id, 
        })
    return render_to_response('reports/room_journal.html', context_instance)
