# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from django import template
from reg.regsys.uprofile import UserProfile
from reg.regsys.room import Room
from reg.regsys.cards import LogJournal
from decorators import require_role
import datetime

@require_role(1, "/error/")
def detail(request, profile_id):
    try:
        u = int(request.GET.get('u'))
    except:
        u = 0
    profile = UserProfile.objects.get(pk=profile_id)
    context_instance=template.RequestContext(request, {'profile':profile, 'u':u})
    return render_to_response('view_profile.html', context_instance)


@require_role(3, "/error/")
def show_my_students(request):
    profile = request.user.get_profile()
    student_list = UserProfile.objects.filter(grade__exact=profile.grade, role__exact=0)
    context_instance=template.RequestContext(request, {'student_list':student_list, 'grade':profile.grade})
    return render_to_response('reports/my_student_list.html', context_instance)
    
    
@require_role(2, "/error/")
def mksysrec(request, profile_id):
    try:
        u = int(request.GET.get('u'))
    except:
        u = 0
        
    try:
        next_url = request.GET.get('next')
        if next_url is None:
            next_url = ''
    except:
        next_url = ''

    print "next=",next_url
    profile = UserProfile.objects.get(pk=profile_id)
    try:
        card = profile.owned_cards.all()[0]
    except:
        return detail(request, profile_id)
        
    card_status = card.logged
    #if card.room_id != 0:
    #card_room = Room.objects.get(pk = card.room_id)
    #else:
    #card_room = None

    user = request.user.get_profile()
    user_status = user.loggedByCard()
    if not user_status[0] or user_status[3] != card.room_id:
        request.user.message_set.create(message = 'ВНИМАНИЕ: Не сте в тази стая!')
        #return HttpResponseRedirect("/profile/" + str(profile_id) + "/?u=1")

    choices = ((1, 'ОТСЪСТВА'), (2, 'ОСВОБОДЕН'), (3, 'ЗАКЪСНЯЛ'))
    if request.method == 'POST':
        log_row = LogJournal.objects.get(pk=card.log_id)
        post_data = request.POST.copy()
        new_status = int(post_data['new_status'][0])
        if new_status == 1:
            log_row.out_event = log_row.in_event
            log_row.log_type = new_status
            log_row.save()
            card.logged = False
            card.room_id = 0
            card.log_id = 0
            card.save()
            request.user.message_set.create(message = 'Записа е успешен')
            if next_url == '':
                return HttpResponseRedirect("/profile/" + str(profile_id) + "/?u=1")
            else:
                return HttpResponseRedirect(next_url)
        elif new_status == 2:
            log_row.out_event = datetime.datetime.today()
            log_row.log_type = new_status
            log_row.save()
            card.logged = False
            card.room_id = 0
            card.log_id = 0
            card.save()
            request.user.message_set.create(message = 'Записа е успешен')
            if next_url == '':
                return HttpResponseRedirect("/profile/" + str(profile_id) + "/?u=1")
            else:
                return HttpResponseRedirect(next_url)
        elif new_status == 3:
            log_row.log_type = new_status
            log_row.save()
            request.user.message_set.create(message = 'Записа е успешен')
            if next_url == '':
                return HttpResponseRedirect("/profile/" + str(profile_id) + "/?u=1")
            else:
                return HttpResponseRedirect(next_url)
        else:
            request.user.message_set.create(message = 'Не са направени промени в електронния дневник');
            if next_url == '':
                return HttpResponseRedirect("/profile/" + str(profile_id) + "/?u=1")
            else:
                return HttpResponseRedirect(next_url)
    else:
        context_instance=template.RequestContext(request, {'profile':profile, 'card_status':card_status, 'uchoices':choices, 'u':u})    
        return render_to_response('forms/profile_mksysrec.html', context_instance)
    
