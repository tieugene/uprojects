# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django import template
from django import newforms as forms
from reg.regsys.uprofile import UserProfile
from reg.regsys.room import Room
from reg.regsys.cards import LogJournal
from django.core.paginator import ObjectPaginator, InvalidPage
import datetime
from decorators import require_role

class GradeSelForm(forms.Form):
    grade = forms.CharField(widget=forms.TextInput(attrs={'size':5}), label = "Клас", max_length=3, required=True)

@require_role(2, "/error/")
def show_students_in_room(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = GradeSelForm(post_data)
    else:
        form = GradeSelForm()
        
    log = request.user.get_profile().loggedByCard()
    if log[0]:
        if form.is_valid():
            students = UserProfile.objects.student_list_in_room(log[3], form.clean_data['grade'].upper().encode('utf-8'))
        else:
            students = None
       
        context_instance=template.RequestContext(request, {'form':form, 'log':log, 'student_list':students})
        return render_to_response('reports/student_list.html', context_instance)

    else:
        request.user.message_set.create(message="Не сте регистрирани в никоя стая. Списъка е недостъпен")
        context_instance=template.RequestContext(request)
        return render_to_response('reports/student_list.html', context_instance)
                
@require_role(2, "/error/")
def show_students_away_room(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = GradeSelForm(post_data)
    else:
        form = GradeSelForm()
        
    log = request.user.get_profile().loggedByCard()
    if log[0]:
        if form.is_valid():
            students = UserProfile.objects.student_list_away_room(log[3], form.clean_data['grade'].upper().encode('utf-8'))
        else:
            students = None
       
        context_instance=template.RequestContext(request, {'form':form, 'log':log, 'student_list':students})
        return render_to_response('reports/student_list_away.html', context_instance)

    else:
        request.user.message_set.create(message="Не сте регистрирани в никоя стая. Списъка е недостъпен")
        context_instance=template.RequestContext(request)
        return render_to_response('reports/student_list_away.html', context_instance)

@require_role(2, "/error/")        
def show_students_list(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = GradeSelForm(post_data)
    else:
        get_data = request.GET.copy()
        form = GradeSelForm(get_data)
        
    log = request.user.get_profile().loggedByCard()
    if log[0]:
        if form.is_valid():
            g = form.clean_data['grade'].upper().encode('utf-8')
            students = UserProfile.objects.student_list_all(g, log[3], )
        else:
            g = ''
            students = None
       
        context_instance=template.RequestContext(request, {'form':form, 'log':log, 'student_list':students, 'g':g})
        return render_to_response('reports/student_list_all.html', context_instance)

    else:
        request.user.message_set.create(message="Не сте регистрирани в никоя стая. Списъка е недостъпен")
        context_instance=template.RequestContext(request)
        return render_to_response('reports/student_list_all.html', context_instance)


class DatesFilterForm(forms.Form):
    beg_date = forms.CharField(widget=forms.TextInput(attrs={'size':10,  'class':'vDateField'}), label = "Нач.дата", max_length=10, required=True)
    beg_hour = forms.CharField(widget=forms.TextInput(attrs={'size':8,  'class':'vTimeField'}), label = "Нач.час", max_length=8, required=True)
    end_date = forms.CharField(widget=forms.TextInput(attrs={'size':10,  'class':'vDateField'}), label = "Кр.дата", max_length=10, required=True)
    end_hour = forms.CharField(widget=forms.TextInput(attrs={'size':8,  'class':'vTimeField'}), label = "Нач.час", max_length=8, required=True)

    def clean_beg_date(self):
        return self.clean_data['beg_date']
        
    def clean_beg_hour(self):
        return self.clean_data['beg_hour']
        
    def clean_end_date(self):
        return self.clean_data['end_date']
        
    def clean_end_hour(self):
        return self.clean_data['end_hour']
        
class DatesFilterForm2(forms.Form):
    beg_date = forms.CharField(widget=forms.TextInput(attrs={'size':10,  'class':'vDateField'}), label = "Нач.дата", max_length=10, required=True)
    beg_hour = forms.CharField(widget=forms.TextInput(attrs={'size':8,  'class':'vTimeField'}), label = "Нач.час", max_length=8, required=True)

    def clean_beg_date(self):
        return self.clean_data['beg_date']
        
    def clean_beg_hour(self):
        return self.clean_data['beg_hour']

@require_role(252, login_url='/error/')
def show_room_list(request):
    rooms = Room.objects.all().order_by('room_number')
    context_instance = template.RequestContext(request, {'room_list':rooms})
    return render_to_response('reports/rooms_list.html', context_instance)
    
@require_role(252, "/error/")
def teachers_status(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = DatesFilterForm2(post_data)

        if form.is_valid():
            adate = form.clean_data['beg_date'].upper().encode('utf-8')
            ahour = form.clean_data['beg_hour'].upper().encode('utf-8')
            print adate, ahour
            res = UserProfile.objects.where_are_teachers(adate, ahour)
        else:
            res = []
    else:
        adate = str(datetime.datetime.today())[:10]
        ahour = '07:30:00'
        res = UserProfile.objects.where_are_teachers(adate, ahour)
        form = DatesFilterForm2({'beg_date':adate, 'beg_hour':ahour})

    context_instance = template.RequestContext(request, 
        {
        'form':form, 
        'teachers':res,
        })
    return render_to_response('reports/teachers_status.html', context_instance)


@require_role(3, "/error/")
def show_user_journal(request,  profile_id):
    profile = UserProfile.objects.get(pk=profile_id)
    if request.method == 'POST':
        post_data = request.POST.copy()
        form = DatesFilterForm(post_data)
        
        if form.is_valid():
            beg_date = form.clean_data['beg_date'].upper().encode('utf-8')
            beg_hour = form.clean_data['beg_hour'].upper().encode('utf-8')
            end_date = form.clean_data['end_date'].upper().encode('utf-8')
            end_hour = form.clean_data['end_hour'].upper().encode('utf-8')
            log = UserProfile.objects.log_journal(profile.id,  beg_date,  beg_hour,  end_date,  end_hour)
        else:
            log = []
                
    else:
        beg_date = str(datetime.datetime.today())[:10]
        beg_hour = '07:30:00'
        end_date = beg_date
        end_hour = '17:30:00'
        log = UserProfile.objects.log_journal(profile.id,  beg_date,  beg_hour,  end_date,  end_hour)
        form = DatesFilterForm({'beg_date':beg_date, 'beg_hour':beg_hour, 'end_date':end_date,  'end_hour':end_hour})
        
    paginator = ObjectPaginator(log, 30)
    try:
        page = int(request.GET.get('page'))
    except:
        page = 1
        
    try:
        log_list = paginator.get_page(page-1)
    except InvalidPage: 
        raise http.Http404

    try:
        u = int(request.GET.get('u'))
    except:
        u = 0
            
    context_instance = template.RequestContext(request, 
        {
        'form':form, 
        'log_list':log_list,
        'paginator':paginator,
        'is_paginated': paginator.pages > 1,
        'has_next': paginator.has_next_page(page - 1),
        'has_previous': paginator.has_previous_page(page - 1),
        'current_page': page,
        'next_page': page + 1,
        'previous_page': page - 1,
        'pages': range(paginator.pages),
        'hits' : paginator.hits,
        'p_id':profile.id,
        'p_name':profile.fullname(),
        'u':u 
        })
    return render_to_response('reports/profile_journal.html', context_instance)

    
